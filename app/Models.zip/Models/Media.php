<?php

namespace App\Models;

use Spatie\MediaLibrary\Models\Media as SpatieMedia;

class Media extends SpatieMedia
{
    // use \Illuminate\Database\Eloquent\SoftDeletes,
    	// \App\Traits\DateFormatter;
    // use \EloquentFilter\Filterable;
}
